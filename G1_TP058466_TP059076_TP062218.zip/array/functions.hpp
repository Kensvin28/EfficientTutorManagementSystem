#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void reg();
bool login();
void create_new_tutor(int, string, string, string, double, string, string, int, string, int, string, int);
void add_new_tutor();
void display();
void search();
void modify();
void sort();
void report();
void remove();
void add_new_staff(int, string, int, string, string);

#endif