#ifndef SEARCH_H
#define SEARCH_H

int search_by_tutor_id(Tutor*, int, int, int);
void validate_number();

#endif