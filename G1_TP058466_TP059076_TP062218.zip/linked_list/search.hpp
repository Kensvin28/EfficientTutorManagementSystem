#ifndef SEARCH_H
#define SEARCH_H

int search_by_tutor_id(int);
void validate_number();

#endif