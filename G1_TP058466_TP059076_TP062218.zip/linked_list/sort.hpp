#ifndef SORT_H
#define SORT_H
#include "data.hpp"
Tutor* merge_sort(Tutor*, int);
Tutor* copy_list(Tutor*);
Tutor* recursive_copy(Tutor*, Tutor*);
#endif