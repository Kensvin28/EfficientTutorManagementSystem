#ifndef ADD_H
#define ADD_H

#include "data.hpp"
#include <string>

Tutor* create_new_tutor_node(int, std::string, std::string, std::string, double, std::string, std::string, int, std::string, int, std::string, int);

#endif