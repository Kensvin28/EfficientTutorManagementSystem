
#ifndef LOGIN_H
#define LOGIN_H

#include "data.hpp"
void insert_to_end(Staff*);

#endif