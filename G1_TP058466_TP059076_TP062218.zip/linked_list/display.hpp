#ifndef DISPLAY_H
#define DISPLAY_H

#include "data.hpp"
void display_detailed_current(Tutor*);
void display_separator();
void display_sorted(Tutor*);

#endif